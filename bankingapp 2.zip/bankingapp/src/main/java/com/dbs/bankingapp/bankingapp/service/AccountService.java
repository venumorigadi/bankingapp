package com.dbs.bankingapp.bankingapp.service;

import com.dbs.bankingapp.bankingapp.domain.SavingsAccount;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AccountService {

    private Map<Long, SavingsAccount> savingsAccountMap = new HashMap<>();

    protected SavingsAccount createSavingsAccount(Long accountID, double initialBalance) {
        SavingsAccount savingsAccount = new SavingsAccount(accountID, initialBalance);
        savingsAccountMap.put(accountID, savingsAccount);
        return savingsAccount;
    }

    public SavingsAccount getSavingsAccount(Long accountID) {
        return savingsAccountMap.get(accountID);
    }

    public double getBalance(Long accountId) {
        return savingsAccountMap.get(accountId).getBalance();
    }
}
