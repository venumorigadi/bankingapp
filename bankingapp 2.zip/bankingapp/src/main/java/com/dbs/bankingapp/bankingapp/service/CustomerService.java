package com.dbs.bankingapp.bankingapp.service;

import com.dbs.bankingapp.bankingapp.domain.Customer;
import com.dbs.bankingapp.bankingapp.domain.SavingsAccount;
import com.dbs.bankingapp.bankingapp.domain.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class CustomerService {
    private Map<Long, Customer> customers = new HashMap<>();
    private Long nextCustomerId = 1L;
    private UUID transactionId = UUID.randomUUID();

    @Autowired
    AccountService accountService;

    @Autowired
    TransactionService transactionService;

    public Customer createCustomer(String name, double initialBalance) {
        Long customerId= nextCustomerId++;
        SavingsAccount savingsAccount = accountService.createSavingsAccount(customerId,initialBalance);
        Customer customer = new Customer(customerId, name, savingsAccount);
        customers.put(customer.getCustomerId(), customer);

        return customer;
    }

    private SavingsAccount getSavingsAccount(double initialBalance) {
        SavingsAccount savingsAccount = new SavingsAccount(nextCustomerId, initialBalance);
        return savingsAccount;
    }

    public Customer getCustomerById(Long customerId) {
        return customers.get(customerId);
    }

    public double checkBalance(Long customerId) {
        Customer customer = customers.get(customerId);
        if (customer != null) {
            return customer.getSavingsAccount().getBalance();
        }
        return 0.0; // or handle as needed
    }

    public List<Transaction> getLastFiveTransactions(Long customerId) {
        // Implement logic to get last 5 transactions for customer
        return Collections.emptyList(); // Placeholder
    }

    /**
     *  Transfer money from one customer to another customer
     * @param fromCustomerId
     * @param toCustomerId
     * @param amount
     * @return
     */

    public boolean transferMoney(Long fromCustomerId, Long toCustomerId, double amount) {
        Customer fromCustomer = customers.get(fromCustomerId);
        Customer toCustomer = customers.get(toCustomerId);
        if (fromCustomer != null && toCustomer != null &&
                fromCustomer.getSavingsAccount().getBalance() >= amount && amount > 0) {

            fromCustomer.getSavingsAccount().withdraw(amount);
            toCustomer.getSavingsAccount().deposit(amount);
            Transaction transaction = new Transaction(UUID.randomUUID(), amount, fromCustomer.getSavingsAccount().getAccountId(), toCustomer.getSavingsAccount().getAccountId(), LocalDateTime.now());
            transactionService.recordTransaction(transaction);
            return true;
        }
        return false;
    }
}

