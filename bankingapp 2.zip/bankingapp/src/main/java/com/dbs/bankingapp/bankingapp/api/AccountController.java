package com.dbs.bankingapp.bankingapp.api;

import com.dbs.bankingapp.bankingapp.domain.SavingsAccount;
import com.dbs.bankingapp.bankingapp.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/accounts")
public class AccountController {
    @Autowired
    private AccountService accountService;


    @GetMapping("/{accountId}")
    public ResponseEntity<SavingsAccount> getAccountId(@PathVariable Long accountId) {
        SavingsAccount savingsAccount = accountService.getSavingsAccount(accountId);
        if (savingsAccount != null) {
            return ResponseEntity.ok(savingsAccount);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{accountId}/balance")
    public ResponseEntity<Double> getBalance(@PathVariable Long accountId) {
        double balance = accountService.getBalance(accountId);
        return ResponseEntity.ok(balance);
    }

}
