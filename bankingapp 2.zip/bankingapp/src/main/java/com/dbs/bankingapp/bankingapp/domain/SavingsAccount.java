package com.dbs.bankingapp.bankingapp.domain;

import org.springframework.context.annotation.Bean;


public class SavingsAccount {
    private Long accountId;
    private double balance;

    public SavingsAccount(Long accountId, double initialBalance) {
        this.accountId = accountId;
        this.balance = initialBalance;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }


    public void withdraw(double amount) {
        balance = balance - amount;
    }

    public void deposit(double amount) {
        balance = balance + amount;
    }
}

