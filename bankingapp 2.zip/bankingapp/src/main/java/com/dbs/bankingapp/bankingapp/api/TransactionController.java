package com.dbs.bankingapp.bankingapp.api;

import com.dbs.bankingapp.bankingapp.domain.Transaction;
import com.dbs.bankingapp.bankingapp.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transactions")
public class TransactionController {
    @Autowired
    private TransactionService transactionService;

    @PostMapping
    public ResponseEntity<String> recordTransaction(@RequestBody Transaction transaction) {
        transactionService.recordTransaction(transaction);
        return ResponseEntity.ok("Transaction recorded");
    }

    @GetMapping
    public ResponseEntity<List<Transaction>> getAllTransactions() {
        List<Transaction> transactions = transactionService.getAllTransactions();
        return ResponseEntity.ok(transactions);
    }
}

