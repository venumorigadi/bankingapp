package com.dbs.bankingapp.bankingapp.domain;

public class Customer {
    private Long customerId;
    private String name;
    private SavingsAccount savingsAccount;

    public Customer(Long custID, String name, SavingsAccount savingsAccount) {
        this.customerId = custID;
        this.name = name;
        this.savingsAccount = savingsAccount;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SavingsAccount getSavingsAccount() {
        return savingsAccount;
    }

    public void setSavingsAccount(SavingsAccount savingsAccount) {
        this.savingsAccount = savingsAccount;
    }




}

