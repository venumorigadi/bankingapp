package com.dbs.bankingapp.bankingapp.api;

import com.dbs.bankingapp.bankingapp.domain.Customer;
import com.dbs.bankingapp.bankingapp.domain.Transaction;
import com.dbs.bankingapp.bankingapp.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestParam String name,
                                                   @RequestParam double initialBalance) {
        Customer customer = customerService.createCustomer(name, initialBalance);
        return ResponseEntity.ok(customer);
    }

    @GetMapping("/{customerId}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable Long customerId) {
        Customer customer = customerService.getCustomerById(customerId);
        if (customer != null) {
            return ResponseEntity.ok(customer);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{customerId}/balance")
    public ResponseEntity<Double> getBalance(@PathVariable Long customerId) {
        double balance = customerService.checkBalance(customerId);
        return ResponseEntity.ok(balance);
    }

    @GetMapping("/{customerId}/transactions")
    public ResponseEntity<List<Transaction>> getLastFiveTransactions(@PathVariable Long customerId) {
        List<Transaction> transactions = customerService.getLastFiveTransactions(customerId);
        return ResponseEntity.ok(transactions);
    }

    @PostMapping("/transfer")
    public ResponseEntity<String> transferMoney(@RequestParam Long fromCustomerId,
                                                @RequestParam Long toCustomerId,
                                                @RequestParam double amount) {
        boolean success = customerService.transferMoney(fromCustomerId, toCustomerId, amount);
        if (success) {
            return ResponseEntity.ok("Transfer successful");
        } else {
            return ResponseEntity.badRequest().body("Transfer failed");
        }
    }
}
